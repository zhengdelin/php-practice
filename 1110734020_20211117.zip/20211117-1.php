<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>1110734020form</title>
    <style type="text/css">
        * {
            margin-bottom: 0.5rem;
            font-size: 1.5rem;
        }
    </style>
</head>

<body>
    <form method="POST" action="/practice/20211117-2.php">
        <label>User:<input type="text" name="user" autofocus></label>
        <br>
        <label>Password:<input type="text" name="password"></label>
        <br>
        <input type="submit" value="下一步">
    </form>
</body>

</html>